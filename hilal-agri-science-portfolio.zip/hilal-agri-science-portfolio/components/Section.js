export default function Section({ id, title, children }) {
  return (
    <section id={id} className="mx-auto max-w-5xl px-6 py-16 md:py-24 scroll-mt-16">
      <h2 className="font-display text-3xl md:text-4xl font-semibold tracking-tight mb-10">{title}</h2>
      {children}
    </section>
  );
}
