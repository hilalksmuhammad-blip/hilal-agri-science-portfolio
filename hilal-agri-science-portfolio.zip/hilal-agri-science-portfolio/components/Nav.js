const links = [['Work', '#work'], ['Experience', '#experience'], ['Skills', '#skills'], ['Education', '#education'], ['Contact', '#contact']];

export default function Nav({ name }) {
  return (
    <header className="sticky top-0 z-10 border-b border-line bg-paper/90 backdrop-blur">
      <nav className="mx-auto max-w-5xl px-6 h-14 flex items-center justify-between gap-4">
        <a href="#top" className="font-display font-semibold">{name}</a>
        <ul className="hidden sm:flex gap-6 text-sm text-muted">
          {links.map(([l, h]) => (
            <li key={h}><a className="hover:text-gel transition-colors" href={h}>{l}</a></li>
          ))}
        </ul>
      </nav>
    </header>
  );
}
