export default function ExperienceItem({ job }) {
  return (
    <article className="grid md:grid-cols-[14rem_1fr] gap-2 md:gap-10 py-8 border-t border-line first:border-t-0 first:pt-0">
      <div>
        <p className="text-muted text-sm">{job.period}</p>
        <p className="text-muted text-sm">{job.place}</p>
      </div>
      <div>
        <h3 className="font-display text-xl font-semibold">{job.role}</h3>
        <p className="text-soil font-medium">{job.org}</p>
        <ul className="mt-3 space-y-2 list-disc pl-5 marker:text-gel">
          {job.points.map((p) => <li key={p}>{p}</li>)}
        </ul>
      </div>
    </article>
  );
}
