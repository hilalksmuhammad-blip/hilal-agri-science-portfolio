import { results } from '../data/content';

export default function Hero({ profile }) {
  const max = Math.max(...results.map((r) => r.value));
  return (
    <div id="top" className="mx-auto max-w-5xl px-6 pt-16 pb-12 md:pt-28 md:pb-20 grid md:grid-cols-5 gap-12 items-center">
      <div className="md:col-span-3">
        <p className="text-soil font-medium mb-4">{profile.title}, {profile.location}</p>
        <h1 className="font-display text-5xl md:text-7xl font-semibold tracking-tight leading-[1.02]">{profile.name}</h1>
        <p className="mt-6 text-lg md:text-xl text-muted max-w-xl">{profile.statement}</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <a href="#work" className="rounded-md bg-gel px-5 py-2.5 font-medium text-paper hover:opacity-90 transition-opacity">View my work</a>
          <a href={`mailto:${profile.email}`} className="rounded-md border border-line px-5 py-2.5 font-medium hover:border-gel transition-colors">Email me</a>
        </div>
      </div>
      <aside className="md:col-span-2 rounded-lg border border-line bg-panel p-5" aria-label="Results from current role">
        <p className="font-display text-lg font-semibold mb-4">Results from my work</p>
        <ul className="space-y-4">
          {results.map((r, i) => (
            <li key={r.label}>
              <div className="flex items-baseline justify-between gap-3 text-sm">
                <span className="text-muted">{r.label}</span>
                <span className="font-display text-xl font-semibold">{r.value}%</span>
              </div>
              <div className="mt-1.5 h-1.5 rounded-full bg-line">
                <div className="bar h-full rounded-full bg-gel" style={{ width: `${(r.value / max) * 100}%`, animationDelay: `${i * 120}ms` }} />
              </div>
            </li>
          ))}
        </ul>
      </aside>
    </div>
  );
}
