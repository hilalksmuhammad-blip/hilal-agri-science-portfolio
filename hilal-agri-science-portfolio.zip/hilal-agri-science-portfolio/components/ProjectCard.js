export default function ProjectCard({ project }) {
  const rows = [['Context', project.context], ['My role', project.contribution], ['Outcome', project.outcome]];
  return (
    <article className="rounded-lg border border-line bg-panel p-6 hover:border-gel transition-colors">
      <h3 className="font-display text-xl font-semibold">{project.name}</h3>
      <dl className="mt-4 space-y-2 text-[0.95rem]">
        {rows.map(([k, v]) => (
          <div key={k} className="grid grid-cols-[5.5rem_1fr] gap-3">
            <dt className="text-muted">{k}</dt>
            <dd>{v}</dd>
          </div>
        ))}
      </dl>
      <ul className="mt-5 flex flex-wrap gap-2">
        {project.tags.map((t) => (
          <li key={t} className="rounded-full border border-line px-3 py-0.5 text-sm text-muted">{t}</li>
        ))}
      </ul>
    </article>
  );
}
