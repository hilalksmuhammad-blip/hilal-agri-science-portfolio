import Nav from '../components/Nav';
import Hero from '../components/Hero';
import Section from '../components/Section';
import ProjectCard from '../components/ProjectCard';
import ExperienceItem from '../components/ExperienceItem';
import { profile, projects, experience, skills, education, certifications } from '../data/content';

export default function Home() {
  return (
    <>
      <Nav name={profile.name} />
      <main>
        <Hero profile={profile} />

        <Section id="about" title="About">
          <div className="max-w-2xl space-y-4 text-lg">
            {profile.about.map((p) => <p key={p}>{p}</p>)}
          </div>
        </Section>

        <Section id="work" title="Featured work">
          <div className="grid md:grid-cols-2 gap-6">
            {projects.map((p) => <ProjectCard key={p.name} project={p} />)}
          </div>
        </Section>

        <Section id="experience" title="Experience">
          {experience.map((j) => <ExperienceItem key={j.role + j.org} job={j} />)}
        </Section>

        <Section id="skills" title="Skills">
          <div className="grid sm:grid-cols-2 gap-x-10 gap-y-8">
            {skills.map((g) => (
              <div key={g.group}>
                <h3 className="font-display text-lg font-semibold mb-2">{g.group}</h3>
                <p className="text-muted">{g.items.join(', ')}</p>
              </div>
            ))}
          </div>
        </Section>

        <Section id="education" title="Education and certifications">
          <div className="grid md:grid-cols-2 gap-10">
            <div className="space-y-6">
              {education.map((e) => (
                <div key={e.title}>
                  <h3 className="font-display text-lg font-semibold">{e.title}</h3>
                  <p className="text-soil">{e.org}, {e.period}</p>
                  <p className="text-muted mt-1">{e.note}</p>
                </div>
              ))}
            </div>
            <ul className="space-y-2 list-disc pl-5 marker:text-gel">
              {certifications.map((c) => <li key={c}>{c}</li>)}
            </ul>
          </div>
        </Section>

        <Section id="contact" title="Contact">
          <p className="max-w-xl text-lg text-muted">Open to conversations about agricultural R&amp;D, food science and quality roles.</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <a href={`mailto:${profile.email}`} className="rounded-md bg-gel px-5 py-2.5 font-medium text-paper hover:opacity-90 transition-opacity">{profile.email}</a>
            <a href={profile.linkedin} target="_blank" rel="noopener noreferrer" className="rounded-md border border-line px-5 py-2.5 font-medium hover:border-gel transition-colors">LinkedIn</a>
          </div>
        </Section>
      </main>
      <footer className="border-t border-line py-8 text-center text-sm text-muted">{profile.name}, {profile.location}</footer>
    </>
  );
}
