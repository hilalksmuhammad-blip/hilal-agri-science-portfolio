# hilal-agri-science-portfolio

A single-page portfolio for Muhammad Hilal K S, an agricultural scientist working on hydrogel formulations and agri-tech R&D. It is built for food, agriculture and quality recruiters, so it leads with trial work and results rather than software projects.

## Tech stack
Next.js 14 (App Router), React 18, Tailwind CSS 3. No API keys or environment variables. Dark mode follows the system setting.

## Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000. Use `npm run build && npm start` for a production build.

## Structure
```
app/         layout, page, global styles (colour tokens live in globals.css)
components/  Nav, Hero, Section, ProjectCard, ExperienceItem
data/        content.js, the only file you need to edit for text
```

## Customise
- Edit `data/content.js` for name, statement, results, projects, experience, skills, education and contact details.
- Change colours in the `:root` blocks of `app/globals.css`.
- The hero results come from the `results` array; keep figures to those you can back up.
- A phone number and home address were left out on purpose. Add them to `profile` if wanted.

## Deploy
Push to GitHub and import the repository into Vercel, or any Next.js host.
