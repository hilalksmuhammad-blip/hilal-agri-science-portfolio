// All portfolio content lives here. Edit this file to customise the site.
// Content is taken only from the CV and LinkedIn profile supplied.

export const profile = {
  name: 'Muhammad Hilal K S',
  title: 'Agricultural Scientist',
  location: 'Manchester, United Kingdom',
  email: 'hilalksmuhammad98@outlook.com',
  linkedin: 'https://www.linkedin.com/in/muhdhila',
  statement:
    'I design and run field and lab trials for hydrogel-based agricultural products, and help scale them from concept to manufacture.',
  about: [
    'I am an Agricultural Scientist at AEH Innovative Hydrogel Ltd, working on hydrogel formulations for plant research and agriculture. I lead applied R&D projects funded by UKRI and industry partners, from trial design through to reporting.',
    'My background combines an MSc in Food Science and Innovation (University of Chester) with a BSc (Hons) in Agriculture and two years managing a university farm in Kerala. That mix lets me move between research, production and quality control.'
  ]
};

// Figures below are quoted from the CV, in the role they belong to.
export const results = [
  { label: 'Product efficiency (UKRI / Agri-Tech Centre hydrogel work)', value: 15 },
  { label: 'Manufacturing costs reduced (scale-up)', value: 20 },
  { label: 'Production workflow efficiency', value: 18 },
  { label: 'Customer engagement (with marketing team)', value: 25 }
];

export const projects = [
  {
    name: 'GeoPonic soil improver: restoring soil fertility',
    context: 'Collaboration with UK Innovate (UKRI) and the Agri-Tech Centre.',
    contribution: 'Designed and executed experiments, and prepared and presented quarterly reports to the funding partners.',
    outcome: 'Hydrogel formulation work on this collaboration contributed to a 15% improvement in product efficiency.',
    tags: ['Experimental design', 'Hydrogel formulation', 'Funder reporting']
  },
  {
    name: 'Hydrogel-based growing media for sustainable rice cultivation',
    context: 'Field trial in Palakkad, Kerala, India, run with AEH Innovation Ltd (UK).',
    contribution: 'Conducted the field-based research trial.',
    outcome: 'Evaluated plant growth, root development and media performance under real agricultural conditions.',
    tags: ['Field trials', 'Crop research', 'Growing media']
  },
  {
    name: 'Antioxidant potential of fruits and vegetables',
    context: 'MSc dissertation: a systematic review and meta-analysis on implications for human health.',
    contribution: 'Led the project end to end.',
    outcome: 'Contributed to evidence-based dietary recommendations.',
    tags: ['Systematic review', 'Meta-analysis', 'Food science']
  },
  {
    name: 'Sustainable development of agricultural enterprises, Edappal',
    context: 'Edappal Grama Panchayath, Malappuram district, Kerala, India.',
    contribution: 'Developed a comprehensive report on sustainable development of agricultural and allied enterprises.',
    outcome: 'Aimed at promoting growth and innovation in the local agricultural sector.',
    tags: ['Rural development', 'Reporting', 'Sustainability']
  }
];

export const experience = [
  {
    role: 'Agricultural Scientist',
    org: 'AEH Innovative Hydrogel Ltd',
    place: 'Manchester, UK',
    period: 'Jan 2024 to present',
    points: [
      'Lead applied R&D projects with UKRI and the UK Agri-Tech Centre, developing hydrogel formulations for plant research and agriculture (15% improvement in product efficiency).',
      'Optimised manufacturing processes and scale-up, reducing costs by 20% and establishing quality control protocols with 100% compliance.',
      'Worked with marketing teams to align product development with market trends (25% increase in customer engagement) and streamlined production workflows (18% efficiency gain).',
      'Coordinated technical support across multiple manufacturing sites, keeping quality standards consistent and delivering programmes on time and within budget.'
    ]
  },
  {
    role: 'Farm Manager',
    org: 'Kerala Agricultural University',
    place: 'Thrissur, India',
    period: 'Oct 2020 to Sep 2022',
    points: [
      'Managed a 24-hectare farm: crop yields up 20% through crop rotation, operating costs down 15% through resource allocation.',
      'Led a team of 25, improving productivity by 25% while keeping full compliance with agricultural regulations.',
      'Oversaw crop quality control, supervised research projects and experiments, and delivered lectures.'
    ]
  },
  {
    role: 'Research and training placements',
    org: 'Kerala Agricultural University and Government of Kerala',
    place: 'Kerala, India',
    period: 'Jul 2019 to Jan 2020',
    points: [
      'Research Assistant (Government of Kerala): field and lab experiments on crop performance, soil health and pest management; farmer training programmes.',
      'Research Intern, Farm Planning (Agricultural Economics): analysed land use, input costs, yields and market prices to propose optimised farm plans.',
      'Internship Trainee, Plant Clinic (Entomology) and Agro-industrial attachment (Agricultural Engineering): farm diagnosis, advisory work and agro-enterprise study.'
    ]
  }
];

export const skills = [
  { group: 'Research and trials', items: ['Crop trial design and field experimentation', 'Research and data analysis', 'SPSS', 'Systematic review'] },
  { group: 'Laboratory and analysis', items: ['UV-Vis spectrophotometry', 'Food rheology and texture analysis', 'Sensory evaluation and panel setup', 'Soil and water quality testing (pH, EC, nutrients)'] },
  { group: 'Hydrogel and agri-tech', items: ['Hydrogel formulation and application in agriculture', 'Sustainable water and irrigation management', 'Manufacturing scale-up'] },
  { group: 'Operations and quality', items: ['Farm management and operations', 'Level 3 HACCP', 'Quality control protocols', 'Project management (Level 3 diploma)'] },
  { group: 'Tools', items: ['Excel', 'Word', 'PowerPoint', 'SharePoint', 'SPSS'] }
];

export const education = [
  { title: 'MSc Food Science and Innovation', org: 'University of Chester, UK', period: '2022 to 2023', note: 'International Scholarship and International Merit Scholarship awards.' },
  { title: 'BSc (Hons) Agriculture', org: 'Kerala Agricultural University, India', period: '2016 to 2020', note: 'Agronomy, plant pathology, soil science, agricultural economics and plant biotechnology.' }
];

export const certifications = [
  'Level 3 HACCP Training',
  'Diploma in Project Management (Level 3)',
  'Future Food: Sustainable Food System for the 21st Century (University of Exeter)',
  'Fertilizer Orientation Course',
  'Associate member, Institute of Food Science and Technology (IFST)'
];
